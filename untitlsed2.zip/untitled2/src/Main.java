public class Main {
    public static void main(String[] args) {
        PatikaStore patikaStore = new PatikaStore();
        patikaStore.run();
    }
}